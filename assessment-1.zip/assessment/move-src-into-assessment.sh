#!/usr/bin/env bash
set -e

ROOT="$(pwd)"
SRC="$ROOT/src"
DEST="$ROOT/assessment/src"
PKG="$ROOT/assessment/package.json"

if [ ! -d "$SRC" ]; then
  echo "No se encontró $SRC. Ejecuta este script desde /home/Cohorte3/Escritorio/Mv/Next/Assessment"
  exit 1
fi

if [ -d "$DEST" ]; then
  echo "Destino $DEST ya existe. Abortando para evitar sobrescritura."
  exit 1
fi

# Preferir git mv para preservar historial
if git rev-parse --is-inside-work-tree > /dev/null 2>&1; then
  echo "Usando git mv para mover src → assessment/src"
  git mv "$SRC" "$DEST" || { echo "git mv falló, intentando mv"; mv "$SRC" "$DEST"; }
else
  echo "No es repo git; usando mv"
  mv "$SRC" "$DEST"
fi

# Actualizar script dev en package.json de assessment
if [ -f "$PKG" ]; then
  echo "Actualizando script dev en $PKG"
  node -e "
const fs = require('fs');
const p = '$PKG';
const j = JSON.parse(fs.readFileSync(p,'utf8'));
j.scripts = j.scripts || {};
j.scripts.dev = 'next dev';
fs.writeFileSync(p, JSON.stringify(j, null, 2));
console.log('OK: updated', p);
"
else
  echo "No se encontró $PKG — crea o adapta package.json manualmente."
fi

echo "Movimiento completado. Ahora:"
echo "  cd assessment"
echo "  npm install"
echo "  npm run dev"
