// Minimal runtime shim for 'next-auth/react' to avoid build-time module-not-found.
// Replace/remove this file once `next-auth` is installed.
export function useSession() {
  return { data: null, status: "unauthenticated" };
}

export async function getSession() {
  return null;
}

export async function signIn(/* provider, options */) {
  // noop shim - you may forward to a real auth flow later

  console.warn(
    "signIn called - shim in use. Install next-auth for real behavior."
  );
}

export async function signOut(/* options */) {
  console.warn(
    "signOut called - shim in use. Install next-auth for real behavior."
  );
}

const _default = null;
export default _default;
