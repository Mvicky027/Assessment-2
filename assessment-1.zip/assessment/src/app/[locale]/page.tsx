"use client";

import React from "react";
import { useSession } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";

type PageParams = {
  locale: string;
};

type PageSearchParams = Record<string, string | string[] | undefined>;

type PageProps = {
  params: PageParams;
};

const Page: React.FC<PageProps> = ({ params }) => {
  const { data: session, status } = useSession();
  const router = useRouter();
  const urlSearchParams = useSearchParams();

  const locale = params.locale;
  const isLoading = status === "loading";
  const userRole = (session?.user?.role as string) ?? "client";

  return (
    <>
      <header>
        <h1>Welcome{session?.user?.name ? `, ${session.user.name}` : ""}</h1>
        <p>Locale: {locale}</p>
        <p>Role: {userRole}</p>
        <p>Status: {status}</p>
      </header>

      <main>
        <button
          type="button"
          onClick={() => {
            router.push(`/${locale}/dashboard`);
          }}
          disabled={isLoading}
        >
          Go to dashboard
        </button>

        <div>
          <strong>Query:</strong> {urlSearchParams?.toString() ?? "none"}
        </div>
      </main>
    </>
  );
};

export default Page;
