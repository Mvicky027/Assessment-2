'use client';

import { useState } from 'react';
import { CreateTicketDTO } from '@/types/ticket';
import { Button } from '../ui/Button';
import { useTranslations } from 'next-intl';

interface TicketFormProps {
  onSubmit: (data: CreateTicketDTO) => void;
  onCancel: () => void;
}

export function TicketForm({ onSubmit, onCancel }: TicketFormProps) {
  const t = useTranslations('tickets');
  const [formData, setFormData] = useState<CreateTicketDTO>({
    title: '',
    description: '',
    priority: 'medium'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.title && formData.description) {
      onSubmit(formData);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium mb-1">
          {t('ticketTitle')}
        </label>
        <input
          type="text"
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          className="w-full border rounded px-3 py-2"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">
          {t('description')}
        </label>
        <textarea
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          className="w-full border rounded px-3 py-2"
          rows={4}
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">
          {t('priority')}
        </label>
        <select
          value={formData.priority}
          onChange={(e) => setFormData({ ...formData, priority: e.target.value as any })}
          className="w-full border rounded px-3 py-2"
        >
          <option value="low">{t('low')}</option>
          <option value="medium">{t('medium')}</option>
          <option value="high">{t('high')}</option>
        </select>
      </div>

      <div className="flex gap-2">
        <Button type="submit" variant="primary">
          {t('create')}
        </Button>
        <Button type="button" variant="secondary" onClick={onCancel}>
          {t('cancel')}
        </Button>
      </div>
    </form>
  );
}