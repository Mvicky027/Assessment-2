'use client';

import { Ticket } from '@/types/ticket';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { useTranslations } from 'next-intl';

interface TicketCardProps {
  ticket: Ticket;
  onView: () => void;
}

export function TicketCard({ ticket, onView }: TicketCardProps) {
  const t = useTranslations('tickets');

  const statusVariant = {
    open: 'info' as const,
    in_progress: 'warning' as const,
    resolved: 'success' as const,
    closed: 'success' as const
  };

  const priorityVariant = {
    low: 'info' as const,
    medium: 'warning' as const,
    high: 'danger' as const
  };

  return (
    <Card>
      <div className="flex justify-between items-start mb-3">
        <h3 className="font-semibold text-lg">{ticket.title}</h3>
        <Badge variant={statusVariant[ticket.status]}>
          {t(ticket.status)}
        </Badge>
      </div>
      
      <p className="text-gray-600 text-sm mb-3 line-clamp-2">
        {ticket.description}
      </p>
      
      <div className="flex gap-2 mb-3">
        <Badge variant={priorityVariant[ticket.priority]}>
          {t(ticket.priority)}
        </Badge>
        <span className="text-xs text-gray-500">
          {new Date(ticket.createdAt).toLocaleDateString()}
        </span>
      </div>
      
      <Button onClick={onView} size="sm">
        Ver detalle
      </Button>
    </Card>
  );
}