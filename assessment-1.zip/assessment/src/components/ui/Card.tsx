'use client';

interface CardProps {
  children: React.ReactNode;
  onClick?: () => void;
}

export function Card({ children, onClick }: CardProps) {
  return (
    <div
      onClick={onClick}
      className={`bg-white border rounded-lg p-4 shadow-sm hover:shadow-md transition ${onClick ? 'cursor-pointer' : ''}`}
    >
      {children}
    </div>
  );
}