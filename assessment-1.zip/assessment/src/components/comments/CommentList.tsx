'use client';

import { Comment } from '@/types/comment';
import { Card } from '../ui/Card';

interface CommentListProps {
  comments: Comment[];
}

export function CommentList({ comments }: CommentListProps) {
  if (comments.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        No hay comentarios todavía
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {comments.map((comment) => (
        <Card key={comment.id}>
          <div className="flex justify-between items-start mb-2">
            <span className="font-medium text-blue-600">
              {comment.authorName}
            </span>
            <span className="text-xs text-gray-500">
              {new Date(comment.createdAt).toLocaleString()}
            </span>
          </div>
          <p className="text-gray-700 whitespace-pre-wrap">
            {comment.message}
          </p>
        </Card>
      ))}
    </div>
  );
}