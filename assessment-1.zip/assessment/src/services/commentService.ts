import axios from 'axios';
import { Comment, CreateCommentDTO } from '@/types/comment';

const API_URL = '/api/comments';

export const commentService = {
  async getByTicketId(ticketId: string): Promise<Comment[]> {
    try {
      const response = await axios.get(`${API_URL}?ticketId=${ticketId}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching comments:', error);
      throw error;
    }
  },

  async create(data: CreateCommentDTO): Promise<Comment> {
    try {
      const response = await axios.post(API_URL, data);
      return response.data;
    } catch (error) {
      console.error('Error creating comment:', error);
      throw error;
    }
  }
};