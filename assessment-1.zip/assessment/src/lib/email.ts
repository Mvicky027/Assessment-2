import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: Number(process.env.EMAIL_PORT),
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

export async function sendTicketCreatedEmail(userEmail: string, ticketTitle: string) {
  try {
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: userEmail,
      subject: 'Ticket creado - HelpDesk Pro',
      html: `
        <h2>Tu ticket ha sido creado exitosamente</h2>
        <p><strong>Título:</strong> ${ticketTitle}</p>
        <p>Nuestro equipo lo revisará pronto.</p>
      `
    });
  } catch (error) {
    console.error('Error sending email:', error);
  }
}

export async function sendTicketResponseEmail(userEmail: string, ticketTitle: string) {
  try {
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: userEmail,
      subject: 'Nueva respuesta en tu ticket - HelpDesk Pro',
      html: `
        <h2>Hay una nueva respuesta en tu ticket</h2>
        <p><strong>Ticket:</strong> ${ticketTitle}</p>
        <p>Revisa tu panel para ver la respuesta.</p>
      `
    });
  } catch (error) {
    console.error('Error sending email:', error);
  }
}

export async function sendTicketClosedEmail(userEmail: string, ticketTitle: string) {
  try {
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: userEmail,
      subject: 'Ticket cerrado - HelpDesk Pro',
      html: `
        <h2>Tu ticket ha sido cerrado</h2>
        <p><strong>Ticket:</strong> ${ticketTitle}</p>
        <p>Gracias por usar HelpDesk Pro.</p>
      `
    });
  } catch (error) {
    console.error('Error sending email:', error);
  }
}