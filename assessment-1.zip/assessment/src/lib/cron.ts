import cron from 'node-cron';
import connectDB from './mongodb';
import { TicketModel } from './models/Ticket';
import { UserModel } from './models/User';
import { CommentModel } from './models/Comment';
import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: Number(process.env.EMAIL_PORT),
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// Ejecutar cada hora
export function startCronJobs() {
  console.log('🕐 Cron jobs iniciados');

  // Recordatorio de tickets sin respuesta (cada hora)
  cron.schedule('0 * * * *', async () => {
    try {
      await connectDB();
      
      // Buscar tickets abiertos o en progreso sin comentarios en las últimas 24 horas
      const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
      
      const tickets = await TicketModel.find({
        status: { $in: ['open', 'in_progress'] },
        updatedAt: { $lt: oneDayAgo }
      }).populate('assignedTo').populate('createdBy');

      for (const ticket of tickets) {
        // Verificar si tiene comentarios recientes
        const recentComments = await CommentModel.findOne({
          ticketId: ticket._id,
          createdAt: { $gt: oneDayAgo }
        });

        if (!recentComments) {
          // Enviar recordatorio al agente asignado
          if (ticket.assignedTo) {
            const agent = ticket.assignedTo as any;
            await transporter.sendMail({
              from: process.env.EMAIL_USER,
              to: agent.email,
              subject: `Recordatorio: Ticket sin respuesta - ${ticket.title}`,
              html: `
                <h2>Ticket sin respuesta por más de 24 horas</h2>
                <p><strong>Ticket:</strong> ${ticket.title}</p>
                <p><strong>Estado:</strong> ${ticket.status}</p>
                <p><strong>Prioridad:</strong> ${ticket.priority}</p>
                <p>Por favor, revisa este ticket lo antes posible.</p>
              `
            });
            console.log(`📧 Recordatorio enviado a ${agent.email} para ticket ${ticket._id}`);
          }
        }
      }
    } catch (error) {
      console.error('Error en cron job de recordatorios:', error);
    }
  });

  // Encuesta de satisfacción para tickets cerrados (diariamente a las 9 AM)
  cron.schedule('0 9 * * *', async () => {
    try {
      await connectDB();
      
      // Buscar tickets cerrados en las últimas 24 horas
      const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000);
      
      const closedTickets = await TicketModel.find({
        status: 'closed',
        updatedAt: { $gt: yesterday }
      }).populate('createdBy');

      for (const ticket of closedTickets) {
        const creator = ticket.createdBy as any;
        if (creator) {
          await transporter.sendMail({
            from: process.env.EMAIL_USER,
            to: creator.email,
            subject: `¿Cómo fue tu experiencia? - ${ticket.title}`,
            html: `
              <h2>Tu ticket ha sido cerrado</h2>
              <p><strong>Ticket:</strong> ${ticket.title}</p>
              <p>Nos gustaría conocer tu opinión sobre el servicio recibido.</p>
              <p>¿El problema fue resuelto satisfactoriamente?</p>
              <p>Tu feedback nos ayuda a mejorar.</p>
            `
          });
          console.log(`📧 Encuesta enviada a ${creator.email}`);
        }
      }
    } catch (error) {
      console.error('Error en cron job de encuestas:', error);
    }
  });
}

// Llamar esta función en tu punto de entrada de la aplicación
// Por ejemplo, en un archivo server.js o en la configuración de Next.js