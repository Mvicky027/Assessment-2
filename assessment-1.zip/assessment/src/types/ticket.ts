export type TicketStatus = 'open' | 'in_progress' | 'resolved' | 'closed';
export type TicketPriority = 'low' | 'medium' | 'high';

export interface Ticket {
  id: string;
  title: string;
  description: string;
  createdBy: string; // User ID
  assignedTo?: string; // Agent ID
  status: TicketStatus;
  priority: TicketPriority;
  createdAt: Date;
  updatedAt: Date;
}

export type CreateTicketDTO = Pick<Ticket, 'title' | 'description' | 'priority'>;
export type UpdateTicketDTO = Partial<Pick<Ticket, 'status' | 'priority' | 'assignedTo'>>;