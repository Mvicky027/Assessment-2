export interface Comment {
  id: string;
  ticketId: string;
  authorId: string;
  authorName: string;
  message: string;
  createdAt: Date;
}

export type CreateCommentDTO = Pick<Comment, 'ticketId' | 'message'>;