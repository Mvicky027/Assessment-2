export type Role = "client" | "agent" | string;

export interface User {
  id: string;
  name?: string | null;
  email?: string | null;
  image?: string | null;
  role?: Role;
}

export interface Session {
  user?: User | null;
  expires?: string;
}

export type TicketStatus = "open" | "in_progress" | "closed" | string;
export type Priority = "low" | "medium" | "high" | string;

export interface Ticket {
  id: string;
  title: string;
  description: string;
  status: TicketStatus;
  priority: Priority;
  createdBy: string; // user id
  assignedTo?: string | null; // agent id
  createdAt: string;
  updatedAt?: string;
}

export interface Comment {
  id: string;
  ticketId: string;
  authorId: string;
  content: string;
  createdAt: string;
}

export type ApiResponse<T = unknown> = {
  success: boolean;
  data?: T;
  error?: string;
};
