declare module "next-auth/react" {
  export type Role = "client" | "agent" | string;

  export type User = {
    id?: string;
    name?: string | null;
    email?: string | null;
    image?: string | null;
    role?: Role | null;
  };

  export type Session = {
    user?: User | null;
    expires?: string;
  };

  export type UseSessionResult = {
    data: Session | null;
    status: "authenticated" | "unauthenticated" | "loading";
  };

  export function useSession(): UseSessionResult;
  export function getSession(): Promise<Session | null>;
  export function signIn(
    provider?: string,
    options?: Record<string, unknown>
  ): Promise<void>;
  export function signOut(options?: Record<string, unknown>): Promise<void>;

  const _default: unknown;
  export default _default;
}

declare module "next/navigation" {
  export type Router = {
    push: (url: string) => void;
    replace?: (url: string) => void;
    back?: () => void;
    refresh?: () => void;
    prefetch?: (url: string) => Promise<void>;
  };

  export function useRouter(): Router;
  export function useSearchParams(): URLSearchParams;
  export function usePathname(): string | null;
  export function redirect(url: string): never;
}
