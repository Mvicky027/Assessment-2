import { useState, useEffect } from 'react';
import { Ticket, CreateTicketDTO, UpdateTicketDTO } from '@/types/ticket';
import { ticketService } from '@/services/ticketService';

export function useTickets(filters?: { status?: string; priority?: string }) {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchTickets = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await ticketService.getAll(filters);
      setTickets(data);
    } catch (err) {
      setError('Error al cargar tickets');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, [filters?.status, filters?.priority]);

  const createTicket = async (data: CreateTicketDTO) => {
    try {
      setError(null);
      const newTicket = await ticketService.create(data);
      setTickets([newTicket, ...tickets]);
      return newTicket;
    } catch (err) {
      setError('Error al crear ticket');
      throw err;
    }
  };

  const updateTicket = async (id: string, data: UpdateTicketDTO) => {
    try {
      setError(null);
      const updated = await ticketService.update(id, data);
      setTickets(tickets.map(t => t.id === id ? updated : t));
      return updated;
    } catch (err) {
      setError('Error al actualizar ticket');
      throw err;
    }
  };

  return {
    tickets,
    loading,
    error,
    fetchTickets,
    createTicket,
    updateTicket
  };
}