const path = require("path");

/** @type {import('next').NextConfig} */
const nextConfig = {
  webpack: (config) => {
    config.resolve = config.resolve || {};
    config.resolve.alias = {
      ...(config.resolve.alias || {}),
      // Alias para resolver imports desde la raíz del repo
      "@": path.resolve(__dirname, "src"),
      "@app": path.resolve(__dirname, "app"),
      "@root": path.resolve(__dirname),
      "@assessment": path.resolve(__dirname, "assessment", "src"),
      // Si usas el shim temporal para next-auth, mapea aquí (quita si instalas next-auth)
      "next-auth/react": path.resolve(
        __dirname,
        "src",
        "shims",
        "next-auth-react.js"
      ),
    };
    return config;
  },
};

module.exports = nextConfig;
