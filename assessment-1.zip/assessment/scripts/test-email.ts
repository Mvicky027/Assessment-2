// Crear transporter
  const transporter = nodemailer.createTransport({
    host: process.env.EMAIL_HOST,
    port: Number(process.env.EMAIL_PORT),
    secure: false,
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS
    }
  });

  try {
    // Verificar conexión
    console.log('🔍 Verificando conexión con el servidor SMTP...');
    await transporter.verify();
    console.log('✅ Conexión exitosa con el servidor SMTP\n');

    // Enviar email de prueba
    console.log('📨 Enviando email de prueba...');
    const info = await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: process.env.EMAIL_USER, // Enviarse a sí mismo
      subject: 'Test - HelpDesk Pro',
      html: `
        <div style="font-family: Arial, sans-serif; padding: 20px;">
          <h2 style="color: #2563eb;">🎉 ¡Email de Prueba Exitoso!</h2>
          <p>Si recibes este email, tu configuración de SMTP está funcionando correctamente.</p>
          <hr style="margin: 20px 0; border: none; border-top: 1px solid #e5e7eb;">
          <p style="color: #6b7280; font-size: 14px;">
            <strong>HelpDesk Pro</strong><br>
            Sistema de Gestión de Tickets
          </p>
        </div>
      `
    });

    console.log('✅ Email enviado exitosamente!');
    console.log(`   Message ID: ${info.messageId}`);
    console.log(`\n📬 Revisa tu bandeja de entrada: ${process.env.EMAIL_USER}`);
    
  } catch (error: any) {
    console.error('❌ Error al enviar email:');
    console.error(`   ${error.message}\n`);
    
    if (error.code === 'EAUTH') {
      console.log('💡 Posible solución:');
      console.log('   - Verifica que EMAIL_USER y EMAIL_PASS sean correctos');
      console.log('   - Si usas Gmail, necesitas una "Contraseña de Aplicación"');
      console.log('   - Genera una aquí: https://myaccount.google.com/apppasswords');
    }
    
    process.exit(1);
  }
}

console.log('================================================');
console.log('   HelpDesk Pro - Test de Configuración Email');
console.log('================================================\n');

testEmail();