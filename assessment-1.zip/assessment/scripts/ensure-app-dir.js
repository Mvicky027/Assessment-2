#!/usr/bin/env node
const fs = require("fs");
const path = require("path");

const projectRoot = process.cwd(); // assessment/
const appDir = path.join(projectRoot, "app");
// Ya NO buscamos ../src/app para evitar duplicados
const parentAppDir = path.join(projectRoot, "..", "app");

function dirExists(p) {
  try {
    return fs.existsSync(p) && fs.lstatSync(p).isDirectory();
  } catch {
    return false;
  }
}

if (dirExists(appDir)) {
  console.log("OK: app directory already exists at", appDir);
  process.exit(0);
}

if (!dirExists(parentAppDir)) {
  console.error(
    "Error: no source app directory found. Expected:",
    parentAppDir
  );
  process.exit(1);
}

try {
  // try to create symlink
  fs.symlinkSync(parentAppDir, appDir, "junction");
  console.log("Created symlink:", appDir, "→", parentAppDir);
} catch (err) {
  console.warn(
    "Symlink failed, attempting recursive copy. Error:",
    err.message
  );
  try {
    if (fs.cpSync) {
      fs.cpSync(parentAppDir, appDir, { recursive: true });
    } else {
      const copyRecursive = (src, dest) => {
        if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
        for (const name of fs.readdirSync(src)) {
          const s = path.join(src, name);
          const d = path.join(dest, name);
          const stat = fs.lstatSync(s);
          if (stat.isDirectory()) copyRecursive(s, d);
          else fs.copyFileSync(s, d);
        }
      };
      copyRecursive(parentAppDir, appDir);
    }
    console.log("Copied app directory from", parentAppDir, "to", appDir);
  } catch (copyErr) {
    console.error("Failed to create app directory via copy:", copyErr);
    process.exit(1);
  }
}

process.exit(0);
