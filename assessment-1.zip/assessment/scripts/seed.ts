import mongoose from 'mongoose';

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/helpdesk-pro';

const UserSchema = new mongoose.Schema({
  name: String,
  email: String,
  password: String,
  role: String,
  createdAt: { type: Date, default: Date.now }
});

const User = mongoose.models.User || mongoose.model('User', UserSchema);

async function seed() {
  try {
    await mongoose.connect(MONGODB_URI);
    console.log('✅ Conectado a MongoDB');

    // Limpiar usuarios existentes (opcional)
    await User.deleteMany({});
    console.log('🗑️  Usuarios anteriores eliminados');

    // Crear usuarios de prueba
    const users = await User.insertMany([
      {
        name: 'Cliente Test',
        email: 'cliente@test.com',
        password: 'password', // En producción usar bcrypt
        role: 'client'
      },
      {
        name: 'Agente Test',
        email: 'agente@test.com',
        password: 'password', // En producción usar bcrypt
        role: 'agent'
      },
      {
        name: 'Juan Pérez',
        email: 'juan@cliente.com',
        password: 'password',
        role: 'client'
      },
      {
        name: 'María García',
        email: 'maria@agente.com',
        password: 'password',
        role: 'agent'
      }
    ]);

    console.log('✅ Usuarios creados:', users.length);
    console.log('\n📋 Usuarios de prueba:');
    console.log('   Cliente: cliente@test.com / password');
    console.log('   Agente: agente@test.com / password\n');

    await mongoose.disconnect();
    console.log('✅ Desconectado de MongoDB');
  } catch (error) {
    console.error('❌ Error:', error);
    process.exit(1);
  }
}

seed();