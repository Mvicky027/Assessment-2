# Helpdesk Pro — Entrega

Resumen rápido

- Proyecto Next.js (App Router). Esta copia ha sido preparada para entrega: incluye instrucciones para comprobar tipos y ejecutar localmente, y un script de preparación.

Requisitos

- Node 18+ / npm
- MongoDB (local o Atlas)
- Variables de entorno (ver `assessment/.env.example`)

Pasos para ejecutar localmente

1. Ir al directorio de la app:
   cd assessment

2. Instalar dependencias:
   npm install

3. Revisar tipos:
   npx tsc --noEmit

4. Arrancar la app en desarrollo:
   npm run dev

Notas sobre estructura y alias

- Si el proyecto contiene duplicados (por ejemplo `src/app` y `app/`), mantener solo `app/` en la raíz. Si no quieres mover carpetas, usa el script `remove-src-app.sh` en la raíz para eliminar `src/app` de forma segura (usa git si aplica).
- El alias `@` está mapeado en `tsconfig.js`/`next.config.js` para resolver imports a `app/` y `src/` (revisa `assessment/next.config.js` y `assessment/tsconfig.json`).

Checklist mínimo de aceptación (para entregar)

- [ ] npm run dev se ejecuta sin fallos críticos (Next arranca).
- [ ] npx tsc --noEmit no muestra errores blocking (o se documentan los errores restantes).
- [ ] Login funcional (ver panel cliente/agent según rol).
- [ ] Crear ticket (cliente) y responder/cerrar (agent) funcionan en UI + endpoints.
- [ ] Hilos de comentarios visibles en detalle del ticket.
- [ ] Emails configurados/documentados (ver .env.example).
- [ ] README incluye pasos para ejecutar, variables env y datos del coder.

Datos del coder (inclúyelos en la entrega)

- Nombre:
- Clan:
- Correo:
- Documento de identidad:

Si quieres, relleno yo la sección "Datos del coder" para incluir en el README final.
